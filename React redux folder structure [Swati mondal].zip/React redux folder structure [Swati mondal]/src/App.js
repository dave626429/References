import Router from "./Router";
import { store, persistor } from "./Redux/store";
import { Provider } from "react-redux";
import { PersistGate } from "redux-persist/integration/react";
import { toast, ToastContainer, Slide } from "react-toastify";

function App() {
  return (
    <Provider store={store}>
      <PersistGate persistor={persistor}>
        <Router />
        <ToastContainer
          transition={Slide}
          hideProgressBar
          position={toast.POSITION.BOTTOM_RIGHT}
          autoClose={3000}
        />
      </PersistGate>
    </Provider>
  );
}

export default App;
