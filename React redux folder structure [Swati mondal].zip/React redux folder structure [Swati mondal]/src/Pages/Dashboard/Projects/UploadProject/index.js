import React, { useState } from "react";
import projectone from "../../../../Assets/Dashboard/projectone.svg";
import projecttwo from "../../../../Assets/Dashboard/projecttwo.svg";
import projectthree from "../../../../Assets/Dashboard/projectthree.svg";
import upload from "../../../../Assets/Dashboard/upload.svg";
import { useNavigate, Link, useLocation } from "react-router-dom";
import { ROUTES } from "../../../../Router/routes";
import { uploadImage } from "../../../../Apis";
import { Spinner } from "react-bootstrap";
import "react-responsive-modal/styles.css";
import { Modal } from "react-responsive-modal";
import "./style.css";
import { useSelector, useDispatch } from "react-redux";
import { addProject } from "../../../../Redux/Actions/actionTypes";
import axios from "axios";

const UploadProject = (props) => {
  const navigate = useNavigate();
  const { state } = useLocation();
  const [loading, setLoading] = useState(false);
  const [open, setOpen] = useState(false);
  const dispatch = useDispatch();

  const onOpenModal = () => setOpen(true);
  const onCloseModal = () => setOpen(false);

  const [projectName, setProjectName] = useState(" ");
  const [projectArea, setProjectArea] = useState(" ");
  const [projectCity, setProjectCity] = useState(" ");

  const ProjectData = [
    {
      projectName: "",
      projectArea: "",
      projectCity: "",
    },
  ];

  const selectImages = (e) => {
    const images = e.target.files;
    console.log(images);

    if (images) {
      setLoading(true);
      const payload = new FormData();
      for (const file of images) {
        payload.append("image", file);
      }
      uploadImage(payload)
        .then((res) => {
          navigate(ROUTES.TAG_PROJECT, {
            state: { data: res?.data, addFromProfile: state?.addFromProfile },
          });
        })
        .finally(() => setLoading(false));
    }
  };

  // function handleSubmit() {
  //   axios
  //     .post(' http://DESKTOP-JTK60MV:8002/api/addProject', {
  //       userId: window.localStorage.getItem('userId'),
  //       name: projectName,
  //       address: projectArea,
  //       city: projectCity
  //     })
  //     .then((response) => {
  //       window.localStorage.setItem('projectId', response.data.data._id)
  //     });
  // }

  const imageSelect = () => {
    navigate(ROUTES.TAG_PROJECT);
  };

  return (
    <>
      <section className="main-section">
        <div className="container-fluid">
          <div className="row">
            <div className="col-md-12 text-start">
              <div className="upload-main">
                <h2>Add Projects </h2>
                <p>
                  Clients are more likely to select listings with project
                  pictures
                </p>
                <div className="boxes d-flex justify-content-between">
                  <div className="boxs-upload upload-one">
                    <img src={projectone} alt="pic" />
                    <h4>
                      Upload Poject photos to get
                      <strong>3X Clients.</strong>
                    </h4>
                  </div>
                  <div className="boxs-upload upload-two">
                    <img src={projecttwo} alt="pic" />
                    <h4>
                      Build <strong> trust</strong> with Clients.
                    </h4>
                  </div>
                  <div className="boxs-upload upload-three">
                    <img src={projectthree} alt="pic" />
                    <h4>
                      Portray your valuable
                      <strong> Experience.</strong>
                    </h4>
                  </div>
                </div>
                <div className="upload-images ">
                  {loading ? (
                    <Spinner animation="border" variant="primary" />
                  ) : (
                    // <i  class="fa fa-plus add" aria-hidden="true"></i>
                    <img onClick={onOpenModal} src={upload} alt="pic" />
                  )}

                  <h3 onClick={onOpenModal}>
                    {loading ? "Uploading Images..." : "Add project Name"}
                  </h3>

                  <Modal open={open} onClose={onCloseModal} center>
                    <div className="row">
                      <form
                        className="projectData"
                        style={{
                          height: "fit-content",
                          borderRadius: "8px",
                        }}
                      >
                        <h5 style={{ marginTop: "2%", color: "#000000" }}>
                          Add Project Name
                        </h5>
                        <div
                          className="form-group"
                          style={{
                            display: "flex",
                            flexDirection: "column",
                            justifyContent: "left",
                            marginTop: "3%",
                          }}
                        >
                          <label>Project Name</label>
                          <input
                            type="text"
                            placeholder="Enter project Name"
                            value={projectName}
                            onChange={(e) => setProjectName(e.target.value)}
                          />
                          <label>Building Name or Area Name</label>
                          <input
                            type="text"
                            placeholder="Enter Building Name or Area Name"
                            value={projectArea}
                            onChange={(e) => setProjectArea(e.target.value)}
                          />
                          <label>City</label>
                          <input
                            type="text"
                            placeholder="Enter City"
                            value={projectCity}
                            onChange={(e) => setProjectCity(e.target.value)}
                          />
                        </div>

                        <Link to={ROUTES.ADD_PHOTOS}>
                          <button
                            onClick={() => {
                              dispatch(
                                addProject({
                                  projectName,
                                  projectArea,
                                  projectCity,
                                })
                              );
                            }}
                            type="submit"
                            className="btn"
                            style={{
                              backgroundColor: "#3B5998",
                              color: "white",
                            }}
                          >
                            Next
                          </button>
                        </Link>
                      </form>
                    </div>
                  </Modal>

                  {/* <input
                    onClick={onOpenModal}
                    multiple
                    accept="image/*"
                    className="pointer"
                  /> */}
                </div>
                <Link to={ROUTES.PLANS}>
                  <p className="text-start upload-skip">Skip Project Upload</p>
                </Link>
              </div>
            </div>
          </div>
        </div>
      </section>
    </>
  );
};

export default UploadProject;
