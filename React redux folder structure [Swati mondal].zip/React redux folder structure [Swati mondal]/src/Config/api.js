export const BASE_URL = "http://3.109.71.144:8000"; 
// export const BASE_URL = "http://DESKTOP-JTK60MV:8002";

export const RAZOR_PAY_KEY = "rzp_test_P2HRVMMubYwNBA";

export const STATUS_CODES = {
  SUCCESS: 200,
};
